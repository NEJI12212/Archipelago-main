MDA1 = "Media Dimension - Area 1"
MDA2 = "Media Dimension - Area 2" # after first boss
MDA3 = "Media Dimension - Area 3" # after second boss
MDA4 = "Media Dimension - Area 4" # 14 red remotes
MDA5 = "Media Dimension - Area 5" # after 3rd boss
MDA6 = "Media Dimension - Area 6" # 26 red remotes

# Levels
OOTL = "Out Of Tune"
SL = "Smellraiser"
GCL = "Gecques Cousteau"
FL = "Frankensteinfeld"
WDCL = "WWW.DOTCOM.COM"
MTTL = "Mao Tse Tongue"
TUSOL = "The Umpire Strikes Out"
P9L = "Pangaea 90210"
FTL = "Fine Tooning"
TOCL = "This Old Cave"
HISTGL = "Honey I Shrunk The Gecko"
PITAL = "Pain In The Asteroids"
SNFL = "Samurai Night Fever"
NWAAFL = "No Weddings And A Funeral"
CZL = "Channel Z" # Final Boss

# Bonus Levels
A2SL = "Aztec 2 Step"
BOL = "Bugged Out"
CADL = "Chips & Dips"
GVML = "Gexzilla vs. Mecharez" #BOSS 3
GIL = "Gilligex Island" # BOSS 1
IDNL = "In Drag Net"
LIACSL = "Lizard in a China Shop"
MPL = "Mooshoo Pork" # BOSS 2
TSWLHL = "The Spy Who Loved Himself"
TT1L = "Thursday the 12th"
